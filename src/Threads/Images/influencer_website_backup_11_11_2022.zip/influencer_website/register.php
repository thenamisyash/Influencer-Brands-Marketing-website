<?php include('app_1.php'); ?>

<?php include('header.php'); ?>
    <!-- //Header Section Start -->
<!-- Content -->
    <div class="container">
        <div class="content" id="form-login">
            <div class="panel-header">
                <div style="display: flex; justify-content: center; margin-top: 50px;">
                    <img src="./files/threads_logo.png" height="40px">
                </div>
                <h2 class="text-center">
                    Register or <a href="#">Login</a>
                </h2>
            </div>
            <div class="panel-body">

                
                <div class="col-xs-12 col-sm-6 col-sm-offset-3">
                    <form class="form-horizontal" method="POST" action="#">
                        <input type="hidden" name="_token" value="op53j4dgYE8HKObDcE949PmIFAqI4pOe3W6OppQI">
                        <div class="form-group">
                            <div class="col-xs-12">
                                <h3>Login Information</h3>
                            </div>
                        </div>
                        <div class="form-group">
                            <div class="col-xs-3">
                                <label for="instagram">Instagram</label>
                            </div>
                            <div class="col-xs-9">
                                <div class="input-group">
                                    <span class="input-group-addon">
                                        <i class="fa fa-brands fa-instagram text-primary"></i>
                                    </span>
                                    <input type="text" id="instagram" name="instagram" value="" class="form-control" placeholder="@username" required></div>
                            </div>
                        </div>
                        <div class="form-group">
                            <div class="col-xs-3">
                                <label for="facebook">Facebook</label>
                            </div>
                            <div class="col-xs-9">
                                <div class="input-group">
                                    <span class="input-group-addon">
                                        <i class="fa fa-brands fa-facebook text-primary"></i>
                                    </span>
                                    <input type="text" name="facebook" value="" placeholder="@username" class="form-control" required="">
                                </div>
                            </div>
                        </div>
                        <div class="form-group">
                            <div class="col-xs-3">
                                <label for="tiktok">Tiktok</label>
                            </div>
                            <div class="col-xs-9">
                                <div class="input-group">
                                    <span class="input-group-addon">
                                        <i class="fa fa-brands fa-tiktok text-primary"></i>
                                    </span>
                                    <input type="text" name="tiktok" placeholder="@username" class="form-control" required="">
                                </div>
                            </div>
                        </div>
                        <div class="form-group">
                            <div class="col-xs-3">
                                <label for="youtube">Youtube</label>
                            </div>
                            <div class="col-xs-9">
                                <div class="input-group">
                                    <span class="input-group-addon">
                                        <i class="fa fa-brands fa-youtube text-primary"></i>
                                    </span>
                                    <input type="text" name="youtube" placeholder="@username" class="form-control" required="">
                                </div>
                            </div>
                        </div>
                        <div class="form-group">
                            <div class="col-xs-3">
                                <label for="twitter">Twitter</label>
                            </div>
                            <div class="col-xs-9">
                                <div class="input-group">
                                    <span class="input-group-addon">
                                        <i class="fa fa-brands fa-twitter text-primary"></i>
                                    </span>
                                    <input type="text" name="twitter" placeholder="@username" class="form-control" required="">
                                </div>
                            </div>
                        </div>
                        <div class="form-group">
                            <div class="col-xs-3">
                                <label for="website">Website</label>
                            </div>
                            <div class="col-xs-9">
                                <div class="input-group">
                                    <span class="input-group-addon">
                                        <i class="fa fa-globe text-primary"></i>
                                    </span>
                                    <input type="text" name="website" placeholder="Website URL" class="form-control" required="">
                                </div>
                            </div>
                        </div>
                        <div class="form-group">
                            <div class="col-xs-12">
                                <script src="./files/api.js.download" async="" defer=""></script>
                                <div class="g-recaptcha" data-sitekey="6LedqhMUAAAAAJA2fDYH6BJ1sj6JNKrTlz0lEw-g">
                                    <div style="width: 304px; height: 78px;">
                                        <div>
                                            <iframe title="reCAPTCHA" src="./files/anchor.html" width="304" height="78" role="presentation" name="a-ju0as84tbc3" frameborder="0" scrolling="no" sandbox="allow-forms allow-popups allow-same-origin allow-scripts allow-top-navigation allow-modals allow-popups-to-escape-sandbox"></iframe>
                                        </div>
                                        <textarea id="g-recaptcha-response" name="g-recaptcha-response" class="g-recaptcha-response" style="width: 250px; height: 40px; border: 1px solid rgb(193, 193, 193); margin: 10px 25px; padding: 0px; resize: none; display: none;"></textarea>
                                    </div>
                                </div>
                            </div>
                            <div class="col-xs-12">
                                <div class="checkbox">
                                    <label>
                                        <input name="terms" id="checkbox" type="checkbox" autocomplete="off"> I Agree to
                                        <a href="#" target="_blank">Terms of Service</a>
                                    </label><br>
                                </div>
                            </div>
                        </div>
                        <input type="hidden" id="type" name="type" value="brand">
                        <div class="form-group ">
                            <div class="col-xs-12">
                                <button type="submit" class="btn btn-primary" cursorshover="true">Register</button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
<?php include('footer.php'); ?>
<?php include('app_2.php'); ?>