<?php include('app_1.php'); ?>

<?php include('header.php'); ?>
    <!-- //Header Section Start -->
<!-- Content -->
    <div class="container">
        <div class="content" id="form-login">
            <div class="panel-header">
                <div style="display: flex; justify-content: center; margin-top: 50px;">
                    <img src="./files/threads_logo.png" height="40px">
                </div>
                <h2 class="text-center">
                    Sign-up as
                </h2>
            </div>
            <div class="panel-body">
                <div class="col-xs-12 col-sm-6 col-sm-offset-3 signup_options">
                    <a href="" class=""><i class="fa-solid fa-user-tie"></i> <span style="padding-left: 20px;">Brand Manager</span></a>
                </div>
                <div class="col-xs-12 col-sm-6 col-sm-offset-3 signup_options">
                    <a href="" class=""><i class="fa-solid fa-building"></i> <span style="padding-left: 20px;">Company</span></a>
                </div>
                <div class="col-xs-12 col-sm-6 col-sm-offset-3 signup_options">
                    <a href="" class=""><i class="fa-solid fa-user-secret"></i> <span style="padding-left: 20px;">Agency</span></a>
                </div>
            </div>
        </div>
    </div>
<?php include('footer.php'); ?>
<?php include('app_2.php'); ?>