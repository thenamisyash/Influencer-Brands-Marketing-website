<!DOCTYPE html>
<?php  
    // if(isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on')   
    //      $url = "https://";
    // else  
    //      $url = "http://";
    // $url.= $_SERVER['HTTP_HOST'];
    $url = $_SERVER['REQUEST_URI'];
?>
<html>
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>
        <?php
            if($url == '/') { 
                echo 'Bounty &amp Threads'; 
            }
            elseif ($url == '/register.php') {
                echo "Sign-up / Login";
            }
            else {
                echo "";
            }
        ?>
    </title>
    <!-- global css Start -->
    <link rel="stylesheet" type="text/css" href="./files/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="./files/font-awesome.min.css">
    <link rel="stylesheet" type="text/css" href="./files/style.css">
    <link rel="stylesheet" type="text/css" href="./files/sweetalert.min.css">
    <link rel="stylesheet" href="./files/all.min.css">
    <!-- //global css End -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.0/css/all.min.css" integrity="sha512-xh6O/CkQoPOWDdYTDqeRdPCVd1SpvCA9XXcUnZS2FmJNp1coAFzvtCN9BmamE+4aHK8yyUHUSCcJHgXloTyT2A==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <!-- global js Start -->
    <script type="text/javascript" async="" src="./files/recaptcha__en.js.download" crossorigin="anonymous" integrity="sha384-j2sah26WlMKQf8EQXBOwWyutNl4NgB7gRqS2vh6bQQwqHC1ZaweKdpbn33FwSCd8"></script>
    <script type="text/javascript" async="" src="./files/recaptcha__en.js.download" crossorigin="anonymous" integrity="sha384-j2sah26WlMKQf8EQXBOwWyutNl4NgB7gRqS2vh6bQQwqHC1ZaweKdpbn33FwSCd8"></script>
    <script async="" src="./files/analytics.js.download"></script>
    <script src="./files/708767192556065" async=""></script>
    <script async="" src="./files/fbevents.js.download"></script>
    <script type="text/javascript" src="./files/jquery.min.js.download"></script>
    <script src="./files/jquery-ui.js.download"></script>
    <script type="text/javascript" src="./files/fixTooltip.js.download"></script>
    <script type="text/javascript" src="./files/bootstrap.js.download"></script>
    <script type="text/javascript" src="./files/bootstrap-select.js.download"></script>
    <script type="text/javascript" src="./files/sweetalert.min.js.download"></script>
    <script type="text/javascript" src="./files/ckeditor.js.download"></script>
    <script type="text/javascript" src="./files/ckeditorInit.js.download"></script>
    <!-- //global js End -->

    <script>
        if (!window.matchMedia || (window.matchMedia("(min-width: 767px)").matches)) {
            // enable tooltips
            $(document).ready(function () {
                $('[data-toggle="tooltip"]').tooltip();
            });
        }
    </script>

    <!-- Facebook Pixel Code -->
    <script>
        !function (f, b, e, v, n, t, s) {
            if (f.fbq) return;
            n = f.fbq = function () {
                n.callMethod ?
                    n.callMethod.apply(n, arguments) : n.queue.push(arguments)
            };
            if (!f._fbq) f._fbq = n;
            n.push = n;
            n.loaded = !0;
            n.version = '2.0';
            n.queue = [];
            t = b.createElement(e);
            t.async = !0;
            t.src = v;
            s = b.getElementsByTagName(e)[0];
            s.parentNode.insertBefore(t, s)
        }(window,
            document, 'script', '//connect.facebook.net/en_US/fbevents.js');
        fbq('init', '708767192556065');
        fbq('track', "PageView");
    </script>
    <noscript><img height="1" width="1" style="display:none"
                   src="https://www.facebook.com/tr?id=708767192556065&ev=PageView&noscript=1"
        /></noscript>
    <!-- End Facebook Pixel Code -->

    <!-- Hotjar Tracking Code for www.shoutcart.com -->
    <script>
        (function(h,o,t,j,a,r){
            h.hj=h.hj||function(){(h.hj.q=h.hj.q||[]).push(arguments)};
            h._hjSettings={hjid:2547523,hjsv:6};
            a=o.getElementsByTagName('head')[0];
            r=o.createElement('script');r.async=1;
            r.src=t+h._hjSettings.hjid+j+h._hjSettings.hjsv;
            a.appendChild(r);
        })(window,document,'https://static.hotjar.com/c/hotjar-','.js?sv=');
    </script><script async="" src="./files/hotjar-2547523.js.download"></script>

    <!-- page level css Start -->
<!-- //page level css End -->

<script type="text/javascript" async="" src="./files/f.txt"></script><script async="" src="./files/modules.fb31143041749935774c.js.download" charset="utf-8"></script><style type="text/css">iframe#_hjRemoteVarsFrame {display: none !important; width: 1px !important; height: 1px !important; opacity: 0 !important; pointer-events: none !important;}</style><style data-cursor="cursor"></style></head>
<?php
    if ($url == '/') {
        echo '<body id="home" data-new-gr-c-s-check-loaded="14.1086.0" data-gr-ext-installed="" class="" style="">';
    }
    else {
        echo '<body class="padding-header" data-new-gr-c-s-check-loaded="14.1086.0" data-gr-ext-installed="">';
    }
?>
<script async="" src="./files/js"></script>
<script>
    window.dataLayer = window.dataLayer || [];
    function gtag(){dataLayer.push(arguments);}
    gtag('js', new Date());

    gtag('config', 'G-L9W7SDVVCS');

</script>
    <script>
        (function (i, s, o, g, r, a, m) {
            i['GoogleAnalyticsObject'] = r;
            i[r] = i[r] || function () {
                (i[r].q = i[r].q || []).push(arguments)
            }, i[r].l = 1 * new Date();
            a = s.createElement(o),
                m = s.getElementsByTagName(o)[0];
            a.async = 1;
            a.src = g;
            m.parentNode.insertBefore(a, m)
        })(window, document, 'script', '//www.google-analytics.com/analytics.js', 'ga');
        ga('create', 'UA-20279429-16', 'auto');
        ga('send', 'pageview');
    </script>
