
<!-- Footer Section Start -->
<footer class="footer" style="background: radial-gradient(#f09464 ,#dd2d37,#dd2d37); height:auto;">
    <div class="container">
        <div class="row">
            <div class="col-xs-6 col-sm-3 col-md-3">
                <h4 class="title">About</h4>
                <ul class="footer__menu">
                    <li><a href="#">Brands &amp; Agencies</a></li>
                    <li><a href="#">How it Works</a></li>
                    <li><a href="#">Success Stories</a></li>
                    <li><a href="#">Contact Us</a></li>
                </ul>
                <h4 class="title">Resources</h4>
                <ul class="footer__menu">
                    <li><a href="#" target="_blank">Blog</a></li>
                    <li><a href="#" target="_blank">Get Help</a></li>
                                            <li><a href="#">For Affiliates</a></li>
                        <li><a href="#">For Influencers</a></li>
                                    </ul>
            </div>

            <div class="col-xs-6 col-sm-3 col-md-3">
                <h4 class="title">Solutions</h4>
                <ul class="footer__menu">
                    <li><a href="#">Instagram Influencers</a></li>
                    <li><a href="#">Mobile App Marketing</a></li>
                    <li><a href="#">Crypto &amp; NFT Marketing <span class="label label-warning">soon</span></a></li>
                </ul>
                <h4 class="title">Partner Solutions</h4>
                <ul class="footer__menu">
                    <li><a href="#" target="_blank" title="Buy Instagram Accounts">Buy Instagram Accounts</a></li>
                    <li><a href="#" target="_blank" title="Buy YouTube Channels">Buy YouTube Channels</a></li>
                    <li><a href="#" target="_blank" title="Buy TikTok Accounts">Buy TikTok Accounts</a></li>
                    <li><a href="#" target="_blank" title="Check Fake Followers">Check Fake Followers</a></li>
                </ul>
            </div>

            <div class="clearfix visible-xs"></div>

            <div class="col-xs-6 col-sm-3 col-md-3">
                <h4 class="title">Find Influencers</h4>
                <ul class="footer__menu">
                    <li><a href="#" title="Find Instagram Influencers" cursorshover="true">Find Instagram Influencers</a></li>
                    <li><a href="#" title="Find Instagram Influencers">Find TikTok Influencers</a></li>
                    <li><a href="#" title="Find YouTube Creators" cursorshover="true">Find YouTube Creators</a></li>
                </ul>
                <h4 class="title">Buy Shoutouts</h4>
                <ul class="footer__menu">
                    <li><a href="#" title="Buy Instagram Reels" cursorshover="true">Buy Instagram Reels</a></li>
                    <!--<li><a href="/buy-instagram-story" title="Buy Instagram Story">Buy Instagram Stories</a></li>!-->
                    <li><a href="#" title="Buy Instagram Carousel">Buy Instagram Carousels</a></li>
                    <li><a href="#" title="Buy TikTok Duet">Buy TikTok Duet</a></li>
                    <li><a href="#" title="Buy TikTok Stitch">Buy TikTok Stitch</a></li>
                    <li><a href="#" title="Buy TikTok Sound">Buy TikTok Sound</a></li>
                </ul>
            </div>

            <div class="col-xs-6 col-sm-3 col-md-3">
                <h4 class="title">Gigs &amp; Services</h4>
                <ul class="footer__menu">
                    <li><a href="#" title="Influencer Gigs &amp; Services" cursorshover="true">All Gigs &amp; Services</a></li>
                    <li><a href="#" title="Social Management Gigs" cursorshover="true">Social Management Gigs</a></li>
                    <li><a href="#" title="Growth &amp; Promotion Gigs">Growth &amp; Promotion Gigs</a></li>
                    <li><a href="#" title="Graphics &amp; Design Gigs">Graphics &amp; Design Gigs</a></li>
                </ul>
                <h4 class="title">Gigs by Type</h4>
                <ul class="footer__menu">
                    <li><a href="#" title="Instagram Gigs" cursorshover="true">Instagram Gigs</a></li>
                    <li><a href="#" title="TikTok Gigs" cursorshover="true">TikTok Gigs</a></li>
                    <li><a href="#" title="YouTube &amp; Facebook Gigs" cursorshover="true">YouTube &amp; Facebook Gigs</a></li>
                </ul>
            </div>

            <div class="col-xs-12">
                <br>
                <p class="copyright">© 2022 Bounty &amp; Threads. <a href="#" style="color:white;">Terms</a> • <a href="#" style="color:white;">Privacy</a></p>
                <br>
            </div>

        </div>
    </div>
</footer>
<!-- //Footer Section End -->