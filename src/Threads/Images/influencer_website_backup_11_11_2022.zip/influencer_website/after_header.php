
<section id="after-header">
    <div class="container text-center">
        <h1>Influencer Marketing by Bounty &amp; Threads</h1>
        <p class="sub-title">
            Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt!
        </p>
        <a href="#" class="btn-browse-influencers" cursorshover="true">Browse Influencers</a>
    </div>
</section> <!--after-header-->
