
<section>
    <div class="container">                       
        <div class="col-xs-12 text-center">                
            <img src="./files/trustedby2.png" alt="brands that trust Shoutcart" style="width:80%;">            
        </div>
    </div>
</section> <!--trusted-by-->