<?php include('app_1.php'); ?>

<?php include('header.php'); ?>
    <!-- //Header Section Start -->
<!-- Content -->
    <div class="container">
        <div class="content" id="form-login">
            <div class="panel-header">
                <h2 class="text-center">
                    Showing top results, use filters to find relevant influencers
                </h2>
            </div>
            <div class="panel-body top-results row">
                <div class="col-xs-3 influencers_top_results">
                    <a href="#">
                        <div class="influencer_dp">
                            <img src="./files/demo_images/Loki.jpg">
                        </div>
                        <div class="username">
                            <h3 class="inf_name">Loki</h3>
                            <span class="inf_username">@GodofMischief</span>
                        </div>
                        <div class="tagline">
                            <p><em>I am the monster parents tell their children about at night.</em></p>
                        </div>
                        <div class="followers">
                            <i class="fa-solid fa-users"></i><span>72,56,98,546 Followers</span>
                        </div>
                    </a>
                </div>
                <div class="col-xs-3 influencers_top_results">
                    <a href="#">
                        <div class="influencer_dp">
                            <img src="./files/demo_images/Deadpool.jpg">
                        </div>
                        <div class="username">
                            <h3 class="inf_name">Deadpool</h3>
                            <span class="inf_username">@FunniestSuperhero</span>
                        </div>
                        <div class="tagline">
                            <p><em>Well, that’s just lazy writing.</em></p>
                        </div>
                        <div class="followers">
                            <i class="fa-solid fa-users"></i><span>65,25,65,423 Followers</span>
                        </div>
                    </a>
                </div>
                <div class="col-xs-3 influencers_top_results">
                    <a href="#">
                        <div class="influencer_dp">
                            <img src="./files/demo_images/Ironman.jpg">
                        </div>
                        <div class="username">
                            <h3 class="inf_name">Ironman</h3>
                            <span class="inf_username">@TonyStark</span>
                        </div>
                        <div class="tagline">
                            <p><em>I AM IRON MAN</em></p>
                        </div>
                        <div class="followers">
                            <i class="fa-solid fa-users"></i><span>98,87,56,132 Followers</span>
                        </div>
                    </a>
                </div>
            </div>
            <div class="panel-body top-results row">
                <div class="col-xs-3 influencers_top_results">
                    <a href="#">
                        <div class="influencer_dp">
                            <img src="./files/demo_images/Thor.jpg">
                        </div>
                        <div class="username">
                            <h3 class="inf_name">Thor</h3>
                            <span class="inf_username">@GodOfThunder</span>
                        </div>
                        <div class="tagline">
                            <p><em>Fortunately, I am mighty!</em></p>
                        </div>
                        <div class="followers">
                            <i class="fa-solid fa-users"></i><span>85,95,65,254 Followers</span>
                        </div>
                    </a>
                </div>
                <div class="col-xs-3 influencers_top_results">
                    <a href="#">
                        <div class="influencer_dp">
                            <img src="./files/demo_images/CaptainAmerica.jpg">
                        </div>
                        <div class="username">
                            <h3 class="inf_name">Steve Rogers</h3>
                            <span class="inf_username">@CaptainAmerica</span>
                        </div>
                        <div class="tagline">
                            <p><em>I can do this all day!</em></p>
                        </div>
                        <div class="followers">
                            <i class="fa-solid fa-users"></i><span>75,65,85,213 Followers</span>
                        </div>
                    </a>
                </div>
                <div class="col-xs-3 influencers_top_results">
                    <a href="#">
                        <div class="influencer_dp">
                            <img src="./files/demo_images/Hulk.jpg">
                        </div>
                        <div class="username">
                            <h3 class="inf_name">Dr. Bruce Banner</h3>
                            <span class="inf_username">@Hulk</span>
                        </div>
                        <div class="tagline">
                            <p><em>Hulk... SMASH!</em></p>
                        </div>
                        <div class="followers">
                            <i class="fa-solid fa-users"></i><span>70,65,02,230 Followers</span>
                        </div>
                    </a>
                </div>
            </div>
        </div>
    </div>
<?php include('footer.php'); ?>
<?php include('app_2.php'); ?>