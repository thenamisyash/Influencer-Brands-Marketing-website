<section class="slider">
    <div class="container text-center">
        <div class="row">
            <div class="col-xs-12 col-md-10 col-md-offset-1 clearfix">
                <div id="carousel-example-generic" class="carousel slide" data-ride="carousel">
                    <!-- Indicators -->
                    <ol class="carousel-indicators">
                        <li data-target="#carousel-example-generic" data-slide-to="0" class=""></li>
                        <li data-target="#carousel-example-generic" data-slide-to="1" class="active"></li>
                        <li data-target="#carousel-example-generic" data-slide-to="2" class=""></li>
                    </ol>

                    <!-- Wrapper for slides -->
                    <div class="carousel-inner" role="listbox">
                        <div class="item active left">
                            <div class="ava">
                                <img src="./files/songplay.png" class="img-circle" alt="">
                            </div>
                            <div class="carousel-caption">
                                <h3>Lorem ipsum dolor sit amet</h3>
                                <p>
                                    Lectus arcu bibendum at varius. Enim sed faucibus turpis in eu mi bibendum. Tortor pretium viverra suspendisse potenti nullam ac.
                                </p>
                            </div>
                        </div>
                        <div class="item next left">
                            <div class="ava">
                                <img src="./files/goaltactics.jpg" class="img-circle" alt="">
                            </div>
                            <div class="carousel-caption">
                                <h3>Lorem ipsum dolor sit amet</h3>
                                <p>
                                    Consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Habitant morbi tristique senectus et.
                                </p>
                            </div>
                        </div>
                        <div class="item">
                            <div class="ava">
                                <img src="./files/santino.jpg" class="img-circle" alt="">
                            </div>
                            <div class="carousel-caption">
                                <h3><i><span>@</span>anonymous</i></h3>
                                <p>
                                    Pellentesque elit eget gravida cum sociis. Blandit massa enim nec dui nunc mattis enim ut tellus.
                                </p>
                            </div>
                        </div>
                    </div>
                </div>
                <a href="javascript: void(0);" data-toggle="modal" data-target="#myModalReg" class="btn-violet-red" cursorshover="true">Register for Free</a>
            </div>
        </div>
    </div>
</section> <!--slider-->

