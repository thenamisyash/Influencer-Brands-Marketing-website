<header class="header" style="height: 120px;">
    <div class="container">
        <div class="row">
            <nav class="navbar navbar-default menu-wrap">
                <div class="container-fluid">
                    <!-- Brand and toggle get grouped for better mobile display -->
                    <div class="navbar-header">
                        <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
                            <span class="icon-bar"></span>
                            <span class="icon-bar"></span>
                            <span class="icon-bar"></span>
                        </button>
                        <a class="navbar-brand" href="#">
                            <img src="./files/main_logo.png" alt="Shoutcart" style="background: rgb(255, 255, 255, 0.25);border-radius: 20px; padding: 10px; box-shadow: 0px 0px 10px #fff;">
                        </a>
                    </div>

                    <!-- Collect the nav links, forms, and other content for toggling -->
                    <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
            <ul class="nav navbar-nav main-menu">
            <li><a href="#" cursorshover="true">Influencers</a></li>
            <li><a href="#" cursorshover="true">Pricing</a></li>
            <li><a href="#" cursorshover="true">Brands &amp; Agencies</a></li>
            <li><a href="#" cursorshover="true">Gigs</a></li>
            <!--<li><a href="/page/how-it-works">How it Works</a></li>!-->
        </ul>
        <ul class="nav navbar-nav navbar-right login-wrap hidden-sm">
            <li><a href="javascript: void(0);" data-toggle="modal" data-target="#myModalLogin" cursorshover="true">Login</a></li>
            <li class="reg"><a href="javascript: void(0);" data-toggle="modal" data-target="#myModalReg" cursorshover="true">Register for
                    Free</a></li>
        </ul>
        <ul class="nav navbar-nav navbar-right login-wrap visible-sm">
            <li class="reg"><a href="javascript: void(0);" data-toggle="modal" data-target="#myModalLogin">Login or
                    Register</a></li>
        </ul>
        </div><!-- /.navbar-collapse -->
                                                            
                </div><!-- /.container-fluid -->
            </nav>
        </div>
    </div>
</header>

<!-- //Header Section End -->
