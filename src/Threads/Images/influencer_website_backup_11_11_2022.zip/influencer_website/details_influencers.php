
<section id="details-influencers">
    <div class="container">
        <div class="row">
            <div class="col-xs-12 col-lg-4">
                <div class="row">
                    <div class="col-xs-12 col-sm-6 col-lg-12">
                        <div class="details-block text-center">
                            <div class="details-icon details-icon_quality"></div>
                            <h3>Top Influencers</h3>
                            <p>
                                Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.
                            </p>
                        </div>
                    </div>

                    <div class="col-xs-12 col-sm-6 col-lg-12">
                        <div class="details-block text-center">
                            <div class="details-icon details-icon_satisfaction"></div>
                            <h3>Guaranteed &amp; Secure</h3>
                            <p>
                               Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit.
                            </p>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-xs-12 col-lg-8 clearfix">
                <div class="iphone-block">
                    <div class="iphone-block__img">
                        <img src="./files/img004.png" alt="iphone">
                    </div>
                </div>
                <div class="details-list">
                    <ul>
                        <li>
                            <span class="details-list__value">8073</span>
                            <span class="details-list__name">Posts</span>
                        </li>
                        <li>
                            <span class="details-list__value">9.7%</span>
                            <span class="details-list__name">Engagement</span>
                        </li>
                        <li>
                            <span class="details-list__value">65.2K</span>
                            <span class="details-list__name">Followers</span>
                        </li>
                    </ul>
                </div>
                <div class="details-block text-center col-xs-12 col-sm-6 col-sm-offset-3 col-md-offset-0">
                    <div class="details-icon details-icon_statistics"></div>
                    <h3>Metrics &amp; Statistics</h3>
                    <p>
                        Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.
                    </p>
                </div>
            </div>

            <div class="col-xs-12 text-center">
                <br><br>
                                <a href="javascript: void(0);" data-toggle="modal" data-target="#myModalReg" class="btn-violet-red" cursorshover="true">Register for Free</a>
                            </div>

        </div>
    </div>
</section> <!--details-influencers-->
