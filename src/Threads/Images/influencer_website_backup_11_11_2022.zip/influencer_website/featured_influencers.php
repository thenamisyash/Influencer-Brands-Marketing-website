<section class="ifluencers-wrap">
    <div class="container">
        <div class="row">
            <div class="col-xs-12 col-md-8 col-md-offset-2 text-center">
                <h2 class="title text-color-charcoal">Featured Influencers</h2>
                <p class="sub-title">
                    Phasellus vestibulum lorem sed risus ultricies tristique. Nibh tellus molestie nunc non blandit massa enim nec dui.
                </p>
            </div>
            <div class="col-xs-12 col-sm-6 col-lg-4">
                <a href="#" class="ifluencers-block">
                    <div class="image-wrap">
                        <img src="./files/WBNFl8NhDe7iM9v.jpeg" alt="Lorem ipsum">
                    </div>
                    <div class="description">
                        <p class="followers">
                            <span>1.7m</span>
                            Subs
                        </p>
                        <span class="teg">

                            <span>@</span><span>Anonymous... <span data-toggle="tooltip" data-placement="bottom" title="" data-original-title="Unlock influencer from profile page"><i class="fa fa-lock text-muted" aria-hidden="true"></i></span></span>
                        </span>
                        <span class="teg">
                            <i class="fa-brands fa-youtube" style="color: #ff0000; font-size:1.3em"></i>
                        </span>
                    </div>
                    <div class="price">
                        $700
                    </div>
                </a>
            </div>
            <div class="col-xs-12 col-sm-6 col-lg-4">
                <a href="#" class="ifluencers-block">
                    <div class="image-wrap">
                        <img src="./files/fyT8phFuBEFHGBh.jpeg" alt="Lorem ipsum" title="Lorem ipsum">
                    </div>
                    <div class="description">
                        <p class="followers">
                            <span>481.4k</span>
                            Followers
                        </p>
                        <span class="teg">

                            <span>@</span><span>Anonymous... <span data-toggle="tooltip" data-placement="bottom" title="" data-original-title="Unlock influencer from profile page"><i class="fa fa-lock text-muted" aria-hidden="true"></i></span></span>
                        </span>
                    </div>
                    <div class="price">
                        $89
                    </div>
                </a>
            </div>
            <div class="col-xs-12 col-sm-6 col-lg-4">
                <a href="#" class="ifluencers-block">
                    <div class="image-wrap">
                        <img src="./files/DITmUBtK0tWuYYe.jpeg" alt="Lorem ipsum" title="Lorem ipsum">
                    </div>
                    <div class="description">
                        <p class="followers">
                            <span>1.6m</span>
                            Followers
                        </p>
                        <span class="teg">

                            <span>@</span><span>Anonymous... <span data-toggle="tooltip" data-placement="bottom" title="" data-original-title="Unlock influencer from profile page"><i class="fa fa-lock text-muted" aria-hidden="true"></i></span></span>
                        </span>
                    </div>
                    <div class="price">
                        $1100
                    </div>
                </a>
            </div>
            <div class="col-xs-12 col-sm-6 col-lg-4">
                <a href="#" class="ifluencers-block">
                    <div class="image-wrap">
                        <img src="./files/dbMwdLEDGgaFWfb.jpeg" alt="Lorem ipsum" title="Lorem ipsum">
                    </div>
                    <div class="description">
                        <p class="followers">
                            <span>805.1k</span>
                            Followers
                        </p>
                        <span class="teg">

                            <span>@</span><span>Anonymous... <span data-toggle="tooltip" data-placement="bottom" title="" data-original-title="Unlock influencer from profile page"><i class="fa fa-lock text-muted" aria-hidden="true"></i></span></span>
                        </span>
                    </div>
                    <div class="price">
                        $100
                    </div>
                </a>
            </div>
            <div class="col-xs-12 col-sm-6 col-lg-4">
                <a href="#" class="ifluencers-block">
                    <div class="image-wrap">
                        <img src="./files/pTjFg5XKxKEFuTW.jpeg" alt="Lorem ipsum" title="Lorem ipsum">
                    </div>
                    <div class="description">
                        <p class="followers">
                            <span>3.2m</span>
                            Followers
                        </p>
                        <span class="teg">

                            <span>@</span><span>Anonymous... <span data-toggle="tooltip" data-placement="bottom" title="" data-original-title="Unlock influencer from profile page"><i class="fa fa-lock text-muted" aria-hidden="true"></i></span></span>
                        </span>
                    </div>
                    <div class="price">
                        $438
                    </div>
                </a>
            </div>
            <div class="col-xs-12 col-sm-6 col-lg-4">
                <a href="#" class="ifluencers-block">
                    <div class="image-wrap">
                        <img src="./files/MYjXlvmYxgRG09O.jpeg" alt="Lorem ipsum" title="Lorem ipsum">
                    </div>
                    <div class="description">
                        <p class="followers">
                            <span>60.8k</span>
                            Subs
                        </p>
                        <span class="teg">

                            <span>@</span><span>Anonymous... <span data-toggle="tooltip" data-placement="bottom" title="" data-original-title="Unlock influencer from profile page"><i class="fa fa-lock text-muted" aria-hidden="true"></i></span></span>
                        </span>
                        <span class="teg">
                            <i class="fa-brands fa-youtube" style="color: #ff0000; font-size:1.3em"></i>
                        </span>
                    </div>
                    <div class="price">
                        $49
                    </div>
                </a>
            </div>
            <div class="col-xs-12 col-sm-6 col-lg-4">
                <a href="#" class="ifluencers-block">
                    <div class="image-wrap">
                        <img src="./files/PQfKZX0Ae15waHO.jpeg" alt="Lorem ipsum" title="Lorem ipsum">
                    </div>
                    <div class="description">
                        <p class="followers">
                            <span>12.2m</span>
                            Followers
                        </p>
                        <span class="teg">

                            <span>@</span><span>Anonymous... <span data-toggle="tooltip" data-placement="bottom" title="" data-original-title="Unlock influencer from profile page"><i class="fa fa-lock text-muted" aria-hidden="true"></i></span></span>
                        </span>
                    </div>
                    <div class="price">
                        $3000
                    </div>
                </a>
            </div>
            <div class="col-xs-12 col-sm-6 col-lg-4">
                <a href="#" class="ifluencers-block">
                    <div class="image-wrap">
                        <img src="./files/f1gRh7H74c8s7ig.jpeg" alt="Lorem ipsum" title="Lorem ipsum">
                    </div>
                    <div class="description">
                        <p class="followers">
                            <span>173.3k</span>
                            Followers
                        </p>
                        <span class="teg">

                            <span>@</span><span>Anonymous... <span data-toggle="tooltip" data-placement="bottom" title="" data-original-title="Unlock influencer from profile page"><i class="fa fa-lock text-muted" aria-hidden="true"></i></span></span>
                        </span>
                    </div>
                    <div class="price">
                        $20
                    </div>
                </a>
            </div>
            <div class="col-xs-12 col-sm-6 col-lg-4">
                <a href="#" class="ifluencers-block">
                    <div class="image-wrap">
                        <img src="./files/qMzbRsi5FPd1qWO.jpeg" alt="Lorem ipsum" title="Lorem ipsum">
                    </div>
                    <div class="description">
                        <p class="followers">
                            <span>1.3m</span>
                            Subs
                        </p>
                        <span class="teg">

                            <span>@</span><span>Anonymous... <span data-toggle="tooltip" data-placement="bottom" title="" data-original-title="Unlock influencer from profile page"><i class="fa fa-lock text-muted" aria-hidden="true"></i></span></span>
                        </span>
                        <span class="teg">
                            <i class="fa-brands fa-youtube" style="color: #ff0000; font-size:1.3em"></i>
                        </span>
                    </div>
                    <div class="price">
                        $120
                    </div>
                </a>
            </div>
            <div class="col-xs-12 text-center">
                <a href="#" class="btn-violet-red" cursorshover="true">Browse Influencers</a>
            </div>
        </div>
    </div>
</section> <!--ifluencers-wrap-->
