<section class="ifluencers-wrap">
    <div class="container">    

        <div class="row">
            <div class="col-xs-12 text-center">
                <h2 class="title text-color-charcoal">Instagram Shoutouts &amp; Influencers</h2>
                <p class="sub-title">
                    Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.
                </p>
            </div>
            <div class="col-xs-12 col-md-6 col-lg-6">
                <div class="col-xs-12">
                    <a href="#" class="ifluencers-block">
                        <div class="image-wrap">
                            <img src="./files/BY1PTHBzLjEEe62.jpeg" alt="Lorem ipsum" title="Lorem ipsum">
                        </div>
                        <div class="description">
                            <p class="followers">
                                <span>839.6k</span>Followers
                            </p>
                            <span class="teg">
                                <span>@</span><span>ano... <span data-toggle="tooltip" data-placement="bottom" title="" data-original-title="Unlock influencer from profile page"><i class="fa fa-lock text-muted" aria-hidden="true"></i></span></span>
                            </span>
                            <span class="teg">
                                <i class="fa-brands fa-instagram"></i>
                            </span>
                        </div>
                        <div class="price">
                            $107
                        </div>
                    </a>
                </div>                        <div class="col-xs-12">
                    <a href="#" class="ifluencers-block">
                        <div class="image-wrap">
                            <img src="./files/PQfKZX0Ae15waHO.jpeg" alt="Lorem ipsum" title="Lorem ipsum">
                        </div>
                        <div class="description">
                            <p class="followers">
                                <span>3.3m</span>Followers
                            </p>
                            <span class="teg">
                                <span>@</span><span>ano... <span data-toggle="tooltip" data-placement="bottom" title="" data-original-title="Unlock influencer from profile page"><i class="fa fa-lock text-muted" aria-hidden="true"></i></span></span>
                            </span>
                            <span class="teg">
                                <i class="fa-brands fa-instagram"></i>
                            </span>
                        </div>
                        <div class="price">
                            $404.6
                        </div>
                    </a>
                </div>                        <div class="col-xs-12">
                    <a href="#" class="ifluencers-block">
                        <div class="image-wrap">
                            <img src="./files/dbMwdLEDGgaFWfb.jpeg" alt="Lorem ipsum" title="Lorem ipsum">
                        </div>
                        <div class="description">
                            <p class="followers">
                                <span>431.3k</span>Followers
                            </p>
                            <span class="teg">
                                <span>@</span><span>ano... <span data-toggle="tooltip" data-placement="bottom" title="" data-original-title="Unlock influencer from profile page"><i class="fa fa-lock text-muted" aria-hidden="true"></i></span></span>
                            </span>
                            <span class="teg">
                                <i class="fa-brands fa-instagram"></i>
                            </span>
                        </div>
                        <div class="price">
                            $102
                        </div>
                    </a>
                </div>                </div>
                <div class="col-xs-12 col-md-6 col-lg-6 text-center">
                    <br><br>
                    <p class="sub-title text-muted">
                        Habitant morbi tristique senectus et. Lectus arcu bibendum at varius. Enim sed faucibus turpis in eu mi bibendum. Tortor pretium viverra suspendisse potenti nullam ac. <a href="#">instagram influencers</a>
                    </p>
                    <ul>
                        <li class="text-muted"><i class="fa fa-check text-primary"></i> Instagram stories + swipe up</li>
                        <li class="text-muted"><i class="fa fa-check text-primary"></i> Giveaway campaigns &amp; contests</li>
                        <li class="text-muted"><i class="fa fa-check text-primary"></i> Product seeding &amp; UGC campaigns</li>
                        <li class="text-muted"><i class="fa fa-check text-primary"></i> Brand mentions &amp; product placement</li>
                        <li class="text-muted"><i class="fa fa-check text-primary"></i> Custom content &amp; video reviews</li>
                    </ul>
                    <a href="#" class="btn-violet-red" cursorshover="true">Browse <i class="fa-brands fa-instagram"></i> Instagram Influencers</a>
                </div>
            </div>
            <br><br><br>


            <div class="row">
                <div class="col-xs-12 text-center">
                    <h2 class="title text-color-charcoal">Tiktok Influencers</h2>
                    <p class="sub-title">
                        Pellentesque elit eget gravida cum sociis. Blandit massa enim nec dui nunc mattis enim ut tellus.
                    </p>
                </div>
                <div class="col-xs-12 col-md-6 col-lg-6">
                    <div class="col-xs-12">
                        <a href="#" class="ifluencers-block">
                            <div class="image-wrap">
                                <img src="./files/zYEY1G5E6Jnawmb.jpeg" alt="Lorem ipsum" title="Lorem ipsum">
                            </div>
                            <div class="description">
                                <p class="followers">
                                    <span>173.3k</span>Followers
                                </p>
                                <span class="teg">
                                    <span>@</span><span>ano... <span data-toggle="tooltip" data-placement="bottom" title="" data-original-title="Unlock influencer from profile page"><i class="fa fa-lock text-muted" aria-hidden="true"></i></span></span>
                                </span>
                                <span class="teg">
                                    <i class="fa-brands fa-tiktok"></i>
                                </span>
                            </div>
                            <div class="price">
                                $20
                            </div>
                        </a>
                    </div>                        <div class="col-xs-12">
                        <a href="#" class="ifluencers-block">
                            <div class="image-wrap">
                                <img src="./files/qMzbRsi5FPd1qWO.jpeg" alt="CLorem ipsum" title="Lorem ipsum">
                            </div>
                            <div class="description">
                                <p class="followers">
                                    <span>3.2m</span>Followers
                                </p>
                                <span class="teg">
                                    <span>@</span><span>ano... <span data-toggle="tooltip" data-placement="bottom" title="" data-original-title="Unlock influencer from profile page"><i class="fa fa-lock text-muted" aria-hidden="true"></i></span></span>
                                </span>
                                <span class="teg">
                                    <i class="fa-brands fa-tiktok"></i>
                                </span>
                            </div>
                            <div class="price">
                                $438
                            </div>
                        </a>
                    </div>                        <div class="col-xs-12">
                        <a href="#" class="ifluencers-block">
                            <div class="image-wrap">
                                <img src="./files/xh04QxU3nDBt30E.jpeg" alt="Lorem ipsum" title="Lorem ipsum">
                            </div>
                            <div class="description">
                                <p class="followers">
                                    <span>18.2m</span>Followers
                                </p>
                                <span class="teg">
                                    <span>@</span><span>ano... <span data-toggle="tooltip" data-placement="bottom" title="" data-original-title="Unlock influencer from profile page"><i class="fa fa-lock text-muted" aria-hidden="true"></i></span></span>
                                </span>
                                <span class="teg">
                                    <i class="fa-brands fa-tiktok"></i>
                                </span>
                            </div>
                            <div class="price">
                                $1500
                            </div>
                        </a>
                    </div>                </div>
                    <div class="col-xs-12 col-md-6 col-lg-6 text-center">
                        <br><br>
                        <p class="sub-title text-muted">
                            Venenatis a condimentum vitae sapien pellentesque habitant morbi tristique. Pellentesque massa placerat duis ultricies lacus sed turpis tincidunt. 
                        </p>
                        <ul>
                            <li class="text-muted"><i class="fa fa-check text-primary"></i> Tiktok shoutouts &amp; merch promotion</li>
                            <li class="text-muted"><i class="fa fa-check text-primary"></i> Music promotion &amp; dances</li>
                            <li class="text-muted"><i class="fa fa-check text-primary"></i> Custom videos &amp; Tiktok challenges</li>
                            <li class="text-muted"><i class="fa fa-check text-primary"></i> Giveaway campaigns &amp; app contests</li>
                            <li class="text-muted"><i class="fa fa-check text-primary"></i> Brand mentions &amp; product placement</li>
                        </ul>
                        <a href="#" class="btn-violet-red">Browse <i class="fa-brands fa-tiktok"></i> Tiktok Influencers</a>
                    </div>
                </div>
                <br><br><br>
                <div class="row">
                    <div class="col-xs-12 text-center">
                        <h2 class="title text-color-charcoal">Youtube Creators</h2>
                        <p class="sub-title">
                            Pellentesque massa placerat duis ultricies lacus sed turpis tincidunt. Id volutpat lacus laoreet non curabitur gravida arcu ac. 
                        </p>
                    </div>
                    <div class="col-xs-12 col-md-6 col-lg-6">
                        <div class="col-xs-12">
                            <a href="#" class="ifluencers-block">
                                <div class="image-wrap">
                                    <img src="./files/30TH7NmaZeuiDhM.jpeg" alt="Lorem ipsum" title="Lorem ipsum">
                                </div>
                                <div class="description">
                                    <p class="followers">
                                        <span>207k</span>Subs
                                    </p>
                                    <span class="teg">
                                        <span>@</span><span>ano... <span data-toggle="tooltip" data-placement="bottom" title="" data-original-title="Unlock influencer from profile page"><i class="fa fa-lock text-muted" aria-hidden="true"></i></span></span>
                                    </span>
                                    <span class="teg">
                                        <i class="fa-brands fa-youtube" style="color: #ff0000; font-size:1.3em"></i>
                                    </span>
                                </div>
                                <div class="price">
                                    $1000
                                </div>
                            </a>
                        </div>                        <div class="col-xs-12">
                            <a href="#" class="ifluencers-block">
                                <div class="image-wrap">
                                    <img src="./files/WBNFl8NhDe7iM9v.jpeg" alt="Lorem ipsum" title="Lorem ipsum">
                                </div>
                                <div class="description">
                                    <p class="followers">
                                        <span>60.8k</span>Subs
                                    </p>
                                    <span class="teg">
                                        <span>@</span><span>ano... <span data-toggle="tooltip" data-placement="bottom" title="" data-original-title="Unlock influencer from profile page"><i class="fa fa-lock text-muted" aria-hidden="true"></i></span></span>
                                    </span>
                                    <span class="teg">
                                        <i class="fa-brands fa-youtube" style="color: #ff0000; font-size:1.3em"></i>
                                    </span>
                                </div>
                                <div class="price">
                                    $49
                                </div>
                            </a>
                        </div>                        <div class="col-xs-12">
                            <a href="#" class="ifluencers-block">
                                <div class="image-wrap">
                                    <img src="./files/x5LOXBrbmBY3pXO.jpeg" alt="Lorem ipsum" title="Lorem ipsum">
                                </div>
                                <div class="description">
                                    <p class="followers">
                                        <span>1.3m</span>Subs
                                    </p>
                                    <span class="teg">
                                        <span>@</span><span>ano... <span data-toggle="tooltip" data-placement="bottom" title="" data-original-title="Unlock influencer from profile page"><i class="fa fa-lock text-muted" aria-hidden="true"></i></span></span>
                                    </span>
                                    <span class="teg">
                                        <i class="fa-brands fa-youtube" style="color: #ff0000; font-size:1.3em"></i>
                                    </span>
                                </div>
                                <div class="price">
                                    $120
                                </div>
                            </a>
                        </div>                </div>
                        <div class="col-xs-12 col-md-6 col-lg-6 text-center">
                            <br><br>
                            <p class="sub-title text-muted">
                                Fermentum posuere urna nec tincidunt praesent semper feugiat. Vitae purus faucibus ornare suspendisse sed. Pretium quam vulputate dignissim suspendisse in est.
                            </p>
                            <ul>
                                <li class="text-muted"><i class="fa fa-check text-primary"></i> Gameplay &amp; tutorial videos</li>
                                <li class="text-muted"><i class="fa fa-check text-primary"></i> Reviews &amp; mention videos</li>
                                <li class="text-muted"><i class="fa fa-check text-primary"></i> Product hauls &amp; lookbook campaigns</li>
                                <li class="text-muted"><i class="fa fa-check text-primary"></i> Unboxing videos &amp; product endorsements</li>
                                <li class="text-muted"><i class="fa fa-check text-primary"></i> Custom content &amp; comedic sketches</li>
                            </ul>
                            <a href="#" class="btn-violet-red">Browse <i class="fa-brands fa-youtube"></i> Youtube Creators</a>
                        </div>
                    </div>
                    <br><br>

                </div>
            </section>